use world;

CREATE TABLE 'txf' (
	'日期' varchar(128) DEFAULT NULL,
	'時間' varchar(128) DEFAULT NULL,
	'成交價' varchar(128) DEFAULT NULL,
	'成交量' varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;